<?php

// ====================== i KNOW BRO YOUR ARE VERY PRO===================//
$ROLEX = file_get_contents("https://playlist-doctor-strange.pages.dev/jiobe.m3u");
$THOR = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://';
$JANE_FOSTER = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '';

$LOKI = str_replace("http://localhost","$THOR/$JANE_FOSTER",$ROLEX);
echo $LOKI;
?>