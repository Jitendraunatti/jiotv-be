<?php



eval(str_rot13(gzinflate(str_rot13(base64_decode('LUnHEoU2Evwal7038oPaE/DIOYfLFk7knOHrzbOXAjGSU8N1dbpM6uH+eOuPcb2HZfl4HIqFwP43L0Y6L3+BoanA/f/On4omo1IqfGgx/gNk2vfSvgobmYvTfB1r77S9c6+Ebqg/EKOmhryUwuVWGe9opEuKXaXSuta3Ex/P21NU0opx+zQDDhS1rN9S/Tt8O6nU7pXRfzix4VbEv96J8kwy2axA7nb+amTgzaca/tC4JaHLLfk0kAg97l7YZ2lTjjihl1SVGntWFZpVbUvh9xu4B8s37SHC99GRuMKd3y89kD39++ytZFAB+lEZcniGuXbhBZHUxqQkjzdl4yZoWQU4odTHwXL1snBbBdb9ipBswPrAvnc0lc92CJluwte+fAtwS9Y8xhQxx3AZCXgFPISkFuLAc+QLgxIpypMc5AVecijQESXCclUzYknH8HYYe5pCYZnl1GX79PW2P8WTs6mf3J/TgjEuGbWY7XBZZJEqIGegeEDeXYSVUhnOF92/6hO6xZZ8tzwXYkZCVwR5/TStN68cflSKnbk6eubtJfOGmeMVZkj8ET3nG5Pzhlho9TpFpPO7AZvrPNM85ypoC0Vc6V0svkTaOqlDUCIo+JRgjaGczRQOXBlNkfJz2VGxMCMe5geSq66VSDJQYYESI1Rz4iYJpdWh7Qxg77E6ubT2/fUr4aW63ZtaqDllUi5k+56IjJV8tjpspydLVs5b1JCLKTUnnXR1FoAi7u1om4/sPkUi/hAp2GpEcKPbCXBRDTBuJ4HmeS9lyvuHVl2cX6/XKDJuKr4E/5wPtF4j35q4pBScw85dj4B20EIWZefpiO18Da9AhGpN5trCp+xo767snJ/vi6PGBrmDMKREMTsvEka0/4rrDLbSJ6ugSuou4OMqitq2ttHmdNztomewMy1b+MLrVkqIdcMP18uDfWQit5zn/AP7li+d7uMH+QsHa91ww7MaQxjCcGREQkUtHU4VAg4R5WU4J42eUK8sCCNu1QXJFjeWmK48C7VA+rqSVId4cl2wk6udK3uJoYAOQHbWQB+GWyF5vrJUbiy1un2e6n2gd4goJcpHpEDDplalzZHT4HdzKzN6HbN79gNDSjvlaAhRz7/5CulMGlp8ExQZ9TjKjxY7fJZ8Ifgu9rrn6z6jEBJ9kCn8alyb6Jsy/e6GHCQbEmLJgrG9TthTnWIbz5PQTNTwT0gfZ0a7oGkpNRUmFfXOih7o86fpK+X1n5BgfGIPX81pbpbsjz7UXS2tCdLpNanaBgVMnlv6tnvro6eR7bWfCpzaJXWs01hBbcI96tNjuK7rDxPWOdPChuDPnRUnyx6BwtIgBu2Cck1cBYlhCH4dnL1H+pmN8L3e2gt9G13Q+L9RWS2Z8AtGlkIBknvRMnBbgZlyxLWb/kkjEYCCphXDDHMU/wqxt4o7Icym406MIF3MvMdMSz+/8SFNppewjOEgJeHxMKRNAMYECA6elMryL/nFe+lQb8X4MKK4fWyqTchzjU+PcBjrIovvNzzvrpg4zvoMcF1WuS2JHJd9YVD6MW5xB7QNK8XFb307pxO6eRI54yPRNaFSrDs+aw35Tvh2okcueSlmJuWKw+X4LXjEow5b3ki+PUwxA2edNWkeDTVKQ3bQww1zR9bMuSVw0BCFjI/mihXxfnyOPsjIvk2oa42ULxi+V08kwZ4tHo6GhZzWhz0HPOvV43DM8iTQITeFIl0JkoDuMImTWH4WDi+DKKQJwYnUaZfCA5lh3SQhWj8xKtYkB85qg5xc2zuIcJmD/ljfeRGNFpSv0v4hkW+l17O9e8a4GzpIOFyD6Zj2XGJqFLjuQKWiglkCUHiytCuF/Xekkc3AzMAJyAT8rgaLTyBabjtBiXC6gO7DDINgPJfa+BBIW94tvaP4VMeuH0KCtGK27CUwA17rNP7h1V97hJ+XI17pUazq8CAHNd+A/XAOP25jdRCsL07/xJWjkCwP7/CVwagrDE+DOqa+y5mW1LMiKgmvFwNb0F1c46/9qtjMdZLn9GuQhLGYfD3mp6iyk6ipIKJxAbcDy4aIPU6t2CfEg6hXZyIIOdr5Z4OaKnip3aARfNfVeM82ZmajxaR2qWbQnTYGEHqv3H42A1GJN0FwA1tgB0uIK3dCE2thTNWJZkN2xC4wdzrRhgHu3u9aaiymw4weFbpqn/30YfP7H4iwr2S8uzbi1W2u6KUAx5Jk0Lkb+5o8Xr0KxenJafY+Iw7MHYME6qexI9/3rq25wHiRKj95v1kTGuxRy+UPmehyTl9ZHc38ubWcGCcH1IAwWy8VHsgP2pFHjwKGeObKUJKVQZdN4WhFVxOnYk53DHyT9+FCM4syO59nIZ8RxLgqcCwXKqTO4e6X2gb+x0rnK7yfgJJJb7ak+83ZoEScRzZKRrQjaLhBxj38bM4ZCnHZ/MwxoJ+yeEvSvisI5psyfflxKFi2n9CGgmDzV6HI8HXL90PJA2pavyH/OZ22Y4EI+6he1LzP29mpC9vHj1SD+fwrdCRB/XA4Wcn+eGDrn/9sj//+DQ==')))));
?>
<html>

<head>
    <title>WEB | <?php echo $THANOS['hname']; ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo $THANOS['himg']; ?>">
    <script disable-devtool-auto='true' src='https://cdn.jsdelivr.net/npm/disable-devtool' clear-log='true' disable-select='true' disable-copy='true' disable-cut='true' disable-paste='true'></script>

    <style>
       body {
    background-image: url(<?php echo $THANOS['bgpic']; ?>);
    background-size: cover;
    background-position: center; 
    background-repeat: no-repeat; 
    background-attachment: fixed; 
}




        header {
            background-color: #212529;
            color: #fff;
            text-align: center;
            padding: 1rem;
        }

        main {
            padding: 1rem;
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            /* Responsive grid */
            gap: 20px;
            /* Add some spacing between grid items */
        }

        .channel-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            background-color: #fff;
            padding: 10px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease-in-out;
        }

        .channel-item:hover {
            transform: translateY(-5px);
        }

        .channel-logo-container {
            width: 150px;
            height: 150px;
            background-color: #f8f9fa;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 10px;
            border: 2px solid #dee2e6;
            border-radius: 50%;
            overflow: hidden;
        }

        .channel-logo {
            max-width: 100%;
            max-height: 100%;
        }

        .channel-name {
            font-weight: bold;
            text-align: center;
            margin-top: 0.5rem;
        }

        a.play-link {
            color: #007bff;
            text-decoration: none;
            transition: color 0.3s ease-in-out;
            margin-top: 0.5rem;
        }

        a.play-link:hover {
            color: #0056b3;
        }

        .search-form {
            margin-bottom: 20px;
            display: flex;
            align-items: center;
        }

        .search-input {
            padding: 10px;
            font-size: 18px;
            border: 2px solid #ced4da;
            border-radius: 5px;
            flex-grow: 1;
            margin-right: 10px;
        }

        .search-button {
            padding: 10px 20px;
            font-size: 18px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease-in-out;
        }

        .search-button:hover {
            background-color: #0056b3;
        }

        /* Media queries for responsiveness */
        @media (max-width: 768px) {
            main {
                grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
            }

            .channel-logo-container {
                width: 120px;
                height: 120px;
            }
        }

        @media (max-width: 480px) {
            main {
                grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
            }

            .channel-logo-container {
                width: 100px;
                height: 100px;
            }
        }
    </style>

</head>

<body>


    <main>
    <?php
eval(str_rot13(gzinflate(str_rot13(base64_decode('LUlUEuy4DT3N1HzvJLVvbKWcZtbGpZxmK57e7LG1IAkQIEACa9DWQc+f72um+zPV259sqjYc/c+6Ldm6/Smnrimf/xN/q7rysSv6tQNhD7sbKuzF8YQxxlg4FmOzofaocT8QbAy16fsXdp8DW7PkKEBh6OykoouojOl/IS5coWDE6KQvrcUGWCX9CzGl4b0d9phZVxWPkZyX4aRKQjvBPtgt63NqEgSDt8OKavuctUm22FbDr0MqId20lOKUnXtNqufRan8FTS3aWq+s9BA8BfvW7dZpHV5UgcO8QJ4NNnQ7MsVm37I0d5Ot0yjcaY7UCvKSs+EoSF6L/AbSaUnsayM8E2+PslsVr5N8exlp3QdYOKynC3U8lCrju3ZjnpL+aa6PkMNW+nQGL7ffERlXaslNSvtSNjQcZ/ey3FIBara7fV9gwGtfDwZmAo8oW96yKWJq99WqYpXbRk/3vUfvp5JWh5iiA2asQgOEXzmOoU+34Wx7fXIGnFM3H20Lw2w5cIbcDIKJDkU9v47KkvAc9ZjzMDdXJfenFIMvUnSbchG3NzNRneHd1LPQjXaq6GxjHsyNcRFvNWPxPjqpESioaFS4G9Evjxac6kjYVKTt/TC/rLwspZbQ2IchAwnDp0ZCSThScRBLZjZHvnvjIjdveEZg9ZSQ3HY6JLfzTO2ozvx1o2gMeCei1yG1ZGKWfv/6N7XLtt2bZKs3kjDYKY9yO2K9Vk1XMszrGIguP0OdsIuIYQsUM5oUCWsJTY7QYl5X6Pa1oXMA0bAZPVCSuJna4/aHGHUupyiz4YquBhuLTQA/0Xf7FJsNybv4rOUc49a08/X5nTp+tgfc5t8LGQnM4F0ptOzAxLc8YXCpDTPaR1X/UNlyss30S2S44dDDTIb4uJU6yQjinmQzfkvD5BJvypB201G5YLMTUBq/0Lt69W0yrhgre9DgXibwS3EK6LKVZVNFWl3JkayoHOdYaZDHlR4UhWvcw+BvLh22lgM2WA8iPfQpUld30gh4tbbuPLaQcp/GxEH9GC48MLtMnkGGyqlacUpGE/LpdkXIG7tVaJKaDt6zYuNP3Lx3qeRoEuUe66vCzksa4qpp63siKNwUqxsSdEYWwXCcchcHvCWCKZGX89Kbj2Z8nfA8/Ihwx0uPhUh40qWvvZ1cWGFP+WBqjIjdTlI0pI8t77emI/E7P+xauVuVp0EEHkCei4vM5GJlUKzf9AjxC0NQsiG5TnXEWmgqifygpBJgr9YydLy5x/H+8Xd1aoUQPj8T7NGpOOd5HblToNVrIOblSiMuGdIsoUQ/9saF9PsQQc5A4a2Uvva7h9hyegSNqb9Unb9DiRKRqc8ipeekSBoGusoQSt5o0OVFJZLsPqT/rp/go6UoOQFFzXnpo0eXTGBjdk92Hj+PH7idFMNJLw1Eiu1ZuJ/kfnUhZKWX37t9yg3ijFxWGmzagx6vNKxEfQxk+sACB97GLZ0oQJ+Pdj1lqhBlzvYZszB+Vb7Sq2AcY8Gc5H5ENpbcpefazqUrmxRtJ9vS5XWREO+W0kaCFL78blqDfPQZisRdQdzh2oF/uW1St9N9B4LhkKxuoCbGMmIK71OskhyocZriyNFH3wXO2r0EpQvQmjLjB7EvNKpmQqGOvJRCviAJG9LiIUjQhFB4AOrekZqM2Sw/RHpd5Bb0cd1+yWSbUMQ8peBPAQb0T5/P9PjVoQj9fAwy3sgLib8l18p83rTN6aZ47D7ew+pubm9CUMSCrK2/qMnrJI+hFKcjwcIPpNS0y5MciNAsR8ReAlQuylL5ZEhONyQKJD7f9gALNdP15W0rvrak7RcfL5hjn6Kru+MV7O+31kgVq188oNZqwIJmLIqjjZIyFepltoQH3rdLJl08bPIXAiery/+6FBIjDTpvEioxXHmpWnf/Mk1q812N71txakUz3+rm0wfIB4PCYgAH8r31xiI9H+c55BytONAdzbPwSOWuRsKMFaISt96TYKNXNycDhdvDh5K2vBrEc1od+ORtYvXVVfFc21YXlmGW6w0x0KYP3Dc9iY1GM5HXnl9TXUOaEdUyig5ZcFo4BdoQ1XfLgy2x/3EiMlN62KN+LQMOpi/NbVMcTsLkmLy8R72Bm2iFlKwfQiHMNcPeZGdRIIqbR5NDj1jGlD6RnnYaWsOD/MmZ8ddQx+Q6liO27WTI7VPeDudG1c6n695PC5g4KN+P5Te0Qe1kIh1QtK5ulONDMqrmzClo1mf+XqhanmbtMhJEk+jNnnrGy8uocKPCGYD3hM7mda5AbmdV9WY3Wzz9s/9+H46ldcNvisGyipEf6uK5O0lzSKsg7xmcmOVPz54GAI0btWDYnV/bj/pDsXAGj/ZDHn0CthKPdTVGVhdJ10cgkVfXP1Ji+xd32KbVBgv1Qh64em2VoKO7P5In//rYf/8LfP/+Lw==')))));
?>
    </main>

</body>

</html>
