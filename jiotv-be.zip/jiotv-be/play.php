<?php
$ROLEX = "LUjXEra4DX2and3c0cvkit4+becmUO+98/SBP27AI1vWTpalo6Ue7n+2/ojXeyiXf8ahSzDkP/MyJfPyQj40SH7/f/K3ospjnwibJYp4i/+Szm1xow/D64wA8E0cX56Rpf4L0sEUBTP8BDARxba/IBuanDL1jkq6K/HVWPw72ku//ogu/lZrOK7VuwAKcYCzOa51LhgBMtU7h6MvW7KSFW2IjV6F3g267Kr494hGdwSxkCS9Yzc0uQ/OJkh66jwq2w8EhawOsU2omCoxRU/ZDKwqX1TAnsGs16o8RqNnD4L6GhOuQUfWKyDlqVCjcWSsnFqRve/HevO6dAvONGvs558AcL+zSppjX6d28zCObBcNBc9iJ3slRYyES2E5brxqXQB+Aqh1KZZnhZVdfTuj3fsTbUYoNnNpDYo5vXldjtChYwbk8nwIEGcnNwbEhkJqtTH0F7KVCOgcqLxwIaT5Tk8wpPzBq7S8HrKwEA6tjlPp8tf1oIq1i3foOWXTDWVGTUsFdCStIhWzFs/kATb9hIC1y87x3QBgXzynPw5F2R4ZDmB16gvB1ACgUm4pRCVYt2BR4iXJ1PQE9Zbt8zO0zQ/22trvl1PqRmZDvwI+PfXfxfK/4P60lY+c0OpnhQN0tHGz5w7dIFwRPoHPTY2vWmzBYfxh/KLh49ADqOjFoJf6Zr4YJ0oWCTsTvU31yNZrocGGq8Zqd/ywpYjCkNLqu3H2NYC5rjjanVwxXKF4pwJH/AXIfcrx166Rsf11IxrOJeazSQxwGmvBjNpgu89k/hmlU7zbKfDTPlA1JHHvIr1Yyv2oI03P4Eb4Rx7Aqt9shzmHEN3FKj68t2S6Dr9UqLQNL6cd6dhuAWqh8szNoB+DyKR71mhxglmHlYKbHQSXAogyvzDevi4xBOlvgbrIxO88TS6Y2zcAcg00eOxnGGgBLAolw7++Ocgq6EK96m+ah85LPrAU+8nml5oZDqlLOP7wJ442k3QGmhY7uN98v2NrrK3T4QgE8NbDLDLAOAPJme4niQ0OTnsZgfmv1YC+1njPu9XBB25MuX2L0bzmOn7kdqCA43ZOgu1mUKDjttMamWIB60rLj+4UdshKMhDVi9cB7wKZQSi29tZKBXxWbuGwHHvJzzjnci1ssG9xnK1CzVTLVh2/epPVpXkS34jjpmMeq6gTKrgl+sQ632pqnlb4IimpXdil7999OtHx0ID6EEDK3qvS7uHBLyA0qvq9XktjMdErZe4zMyvFo5AOngfalDNvervj/iLRGJ+36YyEazKKvem4pjeE/cdU6SriYSEkQGxBL0cWswOGl9lUDHRq3l3s3Gr4E3uE5LL8C2gcAR5snkdOmWT4ezlGwFvCR8vbuO0ZL9+8tViicz/ouuFmnSE3ImcGpBd66fpD1+mrv9W5QOFm4DjAVKboSuq5XIux+HEobBV4UEEey3qk5FXNlJXT+NC4OpNeDrEJQAEBmyiJbw2NZtfRl2/1vWWWnm1T8/J5Np0lIXOEI2X8fWypVtemBRAMZZ9C2q99whLh9l4gaSnwOiwFAKOoFzcCat3TEvlUBu/Mj3c9RoXZKxHRr+O13NENLV+NQYZPZ7kGvYBBfn5UGKBdj3uYx9EtBJ4ujM19vfzkb2lArfcEH86BIacVkwM2IfdG4N+7BiBmVOubbytZdFGY2LOOvrOqF2KdoTnXtvyx/C4kKUb4wU3X+LgBPM6POWtqalN95z83k2o+omBIha0veAc25sK4LDx/KzQd3DY1YzMdBMKGQ/iY3h6BNuVaEcOgzFAxEFQQGNu1vok30jC+P5BA/PpO18kfmjuNkHrBtOHTbGk4Yz3lMVJYHo4QdzeaXHmbIsr6GTEMxnJoncMJIXXKxxWoviawY4fjklTHz5Mwy+tzsxNBmjh5LG4gTj/awT3q0ZXPB91L6Ww4wWPPlJoZPpQFagxtscgDMLljTrJpCQ9liZ/aviX7VcsCNpd23woT96VjF/lFrrlHnMHRoDR4GQ5tKgsapzsZJ4dDRZkRFSnQgGrsQ75Vkv4CWygFk4JfGzabLu2XBgRSOUbcJn+VzlIy+eNqz4aAl2dnktjAlK0E4OVAZoWRGwAAnXaqy5dNNOZEF4xhoh0CidFq5URnYOqkSURC8mC3js/REhVuX4qxPxUW0Y9UVS3qvaEneXgdp76P2TN5vdy/EQyuD79BkND9shrEhxmg6gHBkTwOTwkGLOSpF8Y1uQh6ivSgR97/hfybFrYUwcsSVSgU0+ph3hl4cf0pRAJ3iBQR+sQ2DUE2LjJMIoO/Xik20z6haefyxsPWcZKrwj9yqHM2MuVig4mrzG3bLsUYGCJeEg9z04hXhdcc1qbq1olIWaVoFFSmevwMsrRc2TQooin7A1PmXIwzL/noS9ZGR2RQb4YMLpNzbUfgESvDcNQ8X+eMr6o4fWmanxUxsCAHWKB1+rpvIfUekQL+bse3jSpTuygWE47haD7WMzWu+lzqBtBBMUC3CBkzvdts+vRb33GCRh+GafCCKvNh86zyLz5ZpH7EJqVcEm37rxrimmIwzqXXa1JLU8JLNa7dITti6C6dVaqQy7ydFi3u+/646qTHOhyOFJjF0DpYWXigHAzo4uvkzZZ6hOn9c0LYElF0pDGF8I8d/rz6tPxCrMb1HZvoL9j8+1/v8+//Ag==";
eval(str_rot13(gzinflate(str_rot13(base64_decode($ROLEX)))));
?>
<html>
<head>
    <title><?php echo @$ROLEX['hname']; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
<link rel="shortcut icon" type="image/x-icon" href="<?php echo $ROLEX['himg']; ?>">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/plyr@3.6.2/dist/plyr.css" />
<script src="https://cdn.jsdelivr.net/npm/plyr@3.6.12/dist/plyr.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/hls.js@1.1.4/dist/hls.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
<style>
html {
font-family: Poppins;
background: #000;
margin: 0;
padding: 0
}
.loading {
position: fixed;
top: 0;
left: 0;
width: 100%;
height: 100%;
background: #000;
z-index: 9999;
}
.loading-text {
position: absolute;
top: 0;
bottom: 0;
left: 0;
right: 0;
margin: auto;
text-align: center;
width: 100%;
height: 100px;
line-height: 100px;
}
.loading-text span {
display: inline-block;
margin: 0 5px;
color: #00b3ff;
font-family: 'Quattrocento Sans', sans-serif;
}
    
    .loading-text span:nth-child(1) {
        filter: blur(0px);
        animation: blur-text 1.5s 0s infinite linear alternate;
    }
    
    .loading-text span:nth-child(2) {
        filter: blur(0px);
        animation: blur-text 1.5s 0.2s infinite linear alternate;
    }
    
    .loading-text span:nth-child(3) {
        filter: blur(0px);
        animation: blur-text 1.5s 0.4s infinite linear alternate;
    }
    
    .loading-text span:nth-child(4) {
        filter: blur(0px);
        animation: blur-text 1.5s 0.6s infinite linear alternate;
    }
    
    .loading-text span:nth-child(5) {
        filter: blur(0px);
        animation: blur-text 1.5s 0.8s infinite linear alternate;
    }
    
    .loading-text span:nth-child(6) {
        filter: blur(0px);
        animation: blur-text 1.5s 1.0s infinite linear alternate;
    }
    
    .loading-text span:nth-child(7) {
        filter: blur(0px);
        animation: blur-text 1.5s 1.2s infinite linear alternate;
    }
        .loading-text span:nth-child(8) {
        filter: blur(0px);
        animation: blur-text 1.5s 1.4s infinite linear alternate;
    }
        .loading-text span:nth-child(9) {
        filter: blur(0px);
        animation: blur-text 1.5s 1.6s infinite linear alternate;
    }
        .loading-text span:nth-child(10) {
        filter: blur(0px);
        animation: blur-text 1.5s 1.8s infinite linear alternate;
    }
    .loading-text span:nth-child(11) {
        filter: blur(0px);
        animation: blur-text 1.5s 1.8s infinite linear alternate;
    }
    .loading-text span:nth-child(12) {
        filter: blur(0px);
        animation: blur-text 1.5s 1.8s infinite linear alternate;
    }
    .loading-text span:nth-child(13) {
        filter: blur(0px);
        animation: blur-text 1.5s 1.8s infinite linear alternate;
    }
    .loading-text span:nth-child(14) {
        filter: blur(0px);
        animation: blur-text 1.5s 2.0s infinite linear alternate;
    }     .loading-text span:nth-child(15) {
        filter: blur(0px);
        animation: blur-text 1.5s 2.1s infinite linear alternate;
    }     .loading-text span:nth-child(16) {
        filter: blur(0px);
        animation: blur-text 1.5s 2.2s infinite linear alternate;
    }     .loading-text span:nth-child(17) {
        filter: blur(0px);
        animation: blur-text 1.5s 2.4s infinite linear alternate;
    }     .loading-text span:nth-child(18) {
        filter: blur(0px);
        animation: blur-text 1.5s 2.6s infinite linear alternate;
    }
@keyframes blur-text {
        0% {
            filter: blur(0px);
        }
        100% {
            filter: blur(4px);
        }
    }
     .plyr__video-wrapper::before {
        position: absolute;
        top: 10px;
        right: 10px;
        z-index: 10;
        content: '';
        height: 35px;
        width: 35px;
        background: url('<?php echo @$ROLEX['Rimg']; ?>') no-repeat;
        background-size: 35px auto, auto;
    }

    .plyr__video-wrapper::after {
        position: absolute;
        top: 100px;
        left: 15px;
        z-index: 15;
        content: '';
        height: 150px;
        width: 350px;
        background: url('<?php echo @$ROLEX['Limg']; ?>') no-repeat;
        background-size: 300px auto, auto;
  }
</style>
</head>
<body>
<div id="loading" class="loading">
<div class="loading-text">                                        
    <span style="color:#FF9966"><?php echo @$ROLEX['span'][0]; ?></span>
    <span style="color:#FF9966"><?php echo @$ROLEX['span'][1]; ?></span>
    <span style="color:#FF9966"><?php echo @$ROLEX['span'][2]; ?></span>
    <span style="color:#FF9966"><?php echo @$ROLEX['span'][3]; ?></span>
    <span style="color:#FF9966"><?php echo @$ROLEX['span'][4]; ?></span>
    <span style="color:#FF9966"><?php echo @$ROLEX['span'][5]; ?></span>
    <span style="color:#FF9966"><?php echo @$ROLEX['span'][6]; ?></span>
    <span style="color:#FF9966"><?php echo @$ROLEX['span'][7]; ?></span>
    <span style="color:#FF0000"><?php echo @$ROLEX['span'][8]; ?></span>
    <span style="color:#FF0000"><?php echo @$ROLEX['span'][9]; ?></span>
    <span style="color:#FF0000"><?php echo @$ROLEX['span'][10]; ?></span>
    <span style="color:#FF0000"><?php echo @$ROLEX['span'][11]; ?></span>
    <span style="color:#FF0000"><?php echo @$ROLEX['span'][12]; ?></span>
    <span style="color:#66CC66"><?php echo @$ROLEX['span'][13]; ?></span>
    <span style="color:#66CC66"><?php echo @$ROLEX['span'][14]; ?></span>
    <span style="color:#66CC66"><?php echo @$ROLEX['span'][15]; ?></span>
</div>
</div>

    <video autoplay controls crossorigin poster="<?php echo $ROLEX['pimg']; ?>" playsinline>
      <source src="<?php echo $url; ?>" type="application/x-mpegURL">
    </video>
    <script>
    setTimeout(videovisible, 3000)
    function videovisible() {
    document.getElementById('loading').style.display = 'none';
    }
document.addEventListener("DOMContentLoaded", () => {
    const e = document.querySelector("video"),
        n = e.getElementsByTagName("source")[0].src,
        o = {};
    if (Hls.isSupported()) {
        var config = {
            maxMaxBufferLength: 100,
        };
        const t = new Hls(config);
        t.loadSource(n), t.on(Hls.Events.MANIFEST_PARSED, function(n, l) {
            const s = t.levels.map(e => e.height);
            o.quality = {
                default: s[0],
                options: s,
                forced: !0,
                onChange: e => (function(e) {
                    window.hls.levels.forEach((n, o) => {
                        n.height === e && (window.hls.currentLevel = o)
                    })
                })(e)
            };
            new Plyr(e, o)
        }), t.attachMedia(e), window.hls = t
    } else {
        new Plyr(e, o)
    }
});
</script>
</body>
</html>